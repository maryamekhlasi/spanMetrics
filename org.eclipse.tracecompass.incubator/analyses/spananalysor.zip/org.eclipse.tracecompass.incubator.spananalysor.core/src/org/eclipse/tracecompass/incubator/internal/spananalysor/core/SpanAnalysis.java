/*******************************************************************************
 * Copyright (c) 2024 Ericsson
 *
 * All rights reserved. This program and the accompanying materials are
 * made available under the terms of the Eclipse Public License 2.0 which
 * accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *******************************************************************************/

package org.eclipse.tracecompass.incubator.internal.spananalysor.core;

import java.util.Objects;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.tracecompass.tmf.core.statesystem.ITmfStateProvider;
import org.eclipse.tracecompass.tmf.core.statesystem.TmfStateSystemAnalysisModule;
import org.eclipse.tracecompass.tmf.core.trace.ITmfTrace;

/**
 * Spans scope tracker
 *
 * @author Maryam Ekhlasi
 */
public class SpanAnalysis  extends TmfStateSystemAnalysisModule{
    /**
     * ID
     */
    public static final String ID = "org.eclipse.tracecompass.incubator.spananalysor.core.spananalysis"; //$NON-NLS-1$

    /**
     * Constructor
     */
    public SpanAnalysis() {
        setId(ID);
    }

    @Override
    protected @NonNull ITmfStateProvider createStateProvider() {
        ITmfTrace trace = getTrace();
        return new SpanStateProvider(Objects.requireNonNull(trace));
    }

}
