<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='TARGET_DEFINITION:resource:/org.eclipse.tracecompass.target/baseline/tracecompass-baseline-8.2.0.target' timestamp='1678120440526'>
  <properties size='10'>
    <property name='org.eclipse.pde.core.all_environments' value='false'/>
    <property name='org.eclipse.equinox.p2.cache' value='/home/maryam/Poly/Dorsal/git/spanMetrics/.metadata/.plugins/org.eclipse.pde.core/.bundle_pool'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.pde.core.sequence' value='2'/>
    <property name='org.eclipse.pde.core.includeConfigure' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.ws=gtk,osgi.os=linux,osgi.arch=x86_64'/>
    <property name='org.eclipse.pde.core.provision_mode' value='planner'/>
    <property name='org.eclipse.pde.core.autoIncludeSource' value='true'/>
    <property name='org.eclipse.equinox.p2.nl' value='en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/maryam/Poly/Dorsal/git/spanMetrics/.metadata/.plugins/org.eclipse.pde.core/.install_folders/1678120440526'/>
  </properties>
</profile>
